export interface TyreDetails {
    _id: string
    type: string
    description: string
    long_description: string
    image_name: string
  }
  