export const environment = {
  production: true,
  // configUrl: 'https://your-production-url.com/'
  configUrl: 'https://tyre-api-simons2019s-projects.vercel.app/',
};
